Page({
  data: {
    code: '',
    ext: '',
    showModal: false,
  },

  onShow() {
    wx.login({
      success: (res) => {
        if (res.code) {
          this.setData({
            code: res.code,
            ext: JSON.stringify({
              code: res.code
            })
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    });
  },

  handleTap(e) {
    var that = this;
    wx.request({
      url: 'https://finclip-testing.finogeeks.club/mop/wechat-auth/api/getPhoneNumber',
      data: {
        code: e.detail.code
      },
      success: (r) => {
        if (r.statusCode == 200) {
          that.setData({
            showModal: true,
            modalTitle: '授权成功',
            modalContent: '手机号授权成功，点击下方按钮返回'
          })
          console.log("getPhone success: ", r.statusCode)
        } else {
          console.log("getPhone fail: ", r.statusCode)
          this.setData({
            showModal: true,
            modalTitle: '授权失败',
            modalContent: '手机号授权失败，点击下方按钮返回',
            ext: JSON.stringify({
              statusCode: r.statusCode
            })
          })
        }
      },
      fail: (r) => {
        console.log(r.errMsg, "获取手机号信息失败")
        this.setData({
          showModal: true,
          modalTitle: '授权失败',
          modalContent: '手机号授权失败，点击下方按钮返回',
          ext: JSON.stringify({
            statusCode: r.statusCode
          })
        })
      }
    })
  },
  //隐藏弹窗
  hideModal() {
    this.setData({
      showModal: false
    })
  },
  //截断touchMove事件
  preventTouchMove() {},
  clickBtn() {
    this.setData({
      showModal: false
    })
  }
})